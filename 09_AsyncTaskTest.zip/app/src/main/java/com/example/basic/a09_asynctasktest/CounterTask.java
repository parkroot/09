package com.example.basic.a09_asynctasktest;

import android.os.AsyncTask;
import android.widget.TextView;

public class CounterTask extends AsyncTask<Integer, Integer, Integer> {
    TextView mOutput;
    int mCount = 0;
    int now = 0;

    public void setOutputView(TextView txt) {
        mOutput = txt;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        mCount = 0;
    }

    @Override
    protected Integer doInBackground(Integer... integers) {
        for(int i = 0; i < integers[0]; i++) {
            mCount++;
            now = now + i + 1;
            publishProgress(mCount); // trigger the execution of onProgressUpdate( )
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {;}
        }
        return mCount;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        mOutput.setText("진행상황: " + values[0] + "\n"
        +"현재까지 합 : " + now);
    }

    @Override
    protected void onPostExecute(Integer integer) {
        int r = 0;

        for(int i = 1; i <= integer; i++)
            r = r + i;

        super.onPostExecute(integer);
        mOutput.setText("결과: " + r);
    }

    @Override
    protected void onCancelled(Integer integer) {
        super.onCancelled(integer);
        mOutput.setText("취소됨");
    }
}