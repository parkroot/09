package com.example.basic.a09_remotetest;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class RemoteCalc extends Service {
    public RemoteCalc() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return mBinder;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    ICalc.Stub mBinder = new ICalc.Stub() {
        @Override
        public int multiply(int a, int b) {
            return (a*b);
        }

        @Override
        public int add(int a, int b) {
            return (a+b);
        }
    };
}